import { describe, expect, it } from 'vitest'
import { buildReportLibraryEntries, filterReportLibraryEntries, getReportEntryBridge } from './report-library'
import type { CampaignStats } from '@/lib/types'

const campaigns: CampaignStats[] = [
  {
    campaign_id: 'culture-1',
    campaign_name: 'Loep Cultuurbeeld 2026',
    scan_type: 'culture_assessment',
    organization_id: 'org-1',
    is_active: false,
    created_at: '2025-10-14T09:00:00Z',
    total_invited: 220,
    total_completed: 46,
    completion_rate_pct: 21,
    avg_risk_score: 6.7,
    avg_signal_score: 6.7,
    band_high: 16,
    band_medium: 18,
    band_low: 12,
  },
  {
    campaign_id: 'culture-open-1',
    campaign_name: 'Loep Cultuurbeeld 2027',
    scan_type: 'culture_assessment',
    organization_id: 'org-1',
    is_active: true,
    created_at: '2025-10-15T09:00:00Z',
    total_invited: 240,
    total_completed: 52,
    completion_rate_pct: 22,
    avg_risk_score: 6.9,
    avg_signal_score: 6.9,
    band_high: 20,
    band_medium: 19,
    band_low: 13,
  },
  {
    campaign_id: 'exit-1',
    campaign_name: 'ExitScan Ops — Q3',
    scan_type: 'exit',
    organization_id: 'org-1',
    is_active: true,
    created_at: '2025-10-12T09:00:00Z',
    total_invited: 24,
    total_completed: 14,
    completion_rate_pct: 58,
    avg_risk_score: 5.9,
    avg_signal_score: 6.1,
    band_high: 6,
    band_medium: 5,
    band_low: 3,
  },
  {
    campaign_id: 'pulse-1',
    campaign_name: 'Pulse week 36-38',
    scan_type: 'pulse',
    organization_id: 'org-1',
    is_active: true,
    created_at: '2025-09-22T09:00:00Z',
    total_invited: 80,
    total_completed: 11,
    completion_rate_pct: 13,
    avg_risk_score: 4.6,
    avg_signal_score: 4.8,
    band_high: 2,
    band_medium: 6,
    band_low: 3,
  },
  {
    campaign_id: 'onboarding-1',
    campaign_name: 'Onboarding cohort sep 25',
    scan_type: 'onboarding',
    organization_id: 'org-1',
    is_active: true,
    created_at: '2025-10-01T09:00:00Z',
    total_invited: 18,
    total_completed: 7,
    completion_rate_pct: 39,
    avg_risk_score: 5.1,
    avg_signal_score: 5.1,
    band_high: 2,
    band_medium: 3,
    band_low: 2,
  },
  {
    campaign_id: 'tiny-1',
    campaign_name: 'Nog te klein',
    scan_type: 'retention',
    organization_id: 'org-1',
    is_active: true,
    created_at: '2025-10-10T09:00:00Z',
    total_invited: 40,
    total_completed: 4,
    completion_rate_pct: 10,
    avg_risk_score: 5.2,
    avg_signal_score: 5.2,
    band_high: 1,
    band_medium: 2,
    band_low: 1,
  },
]

describe('report library', () => {
  it('builds only report-ready entries and marks one featured management report', () => {
    const model = buildReportLibraryEntries(campaigns)

    expect(model.entries.map((entry) => entry.campaignId)).toEqual(['culture-1', 'exit-1', 'onboarding-1', 'pulse-1'])
    expect(model.featured).toMatchObject({
      campaignId: 'culture-1',
      scanType: 'culture_assessment',
    })
    expect(model.entries.find((entry) => entry.campaignId === 'culture-1')?.recommended).toBe(true)
  })

  it('keeps an open culture assessment baseline out of the report library until close', () => {
    const model = buildReportLibraryEntries(campaigns)

    expect(model.entries.some((entry) => entry.campaignId === 'culture-open-1')).toBe(false)
  })

  it('formats the featured subtitle without encoding artifacts', () => {
    const model = buildReportLibraryEntries(campaigns)

    expect(model.featured?.subtitle).toContain('·')
    expect(model.featured?.subtitle).not.toContain('Â·')
  })

  it('maps management, module and cohort categories in a bounded way', () => {
    const model = buildReportLibraryEntries(campaigns)

    expect(model.entries.find((entry) => entry.campaignId === 'culture-1')?.category).toBe('management')
    expect(model.entries.find((entry) => entry.campaignId === 'exit-1')?.category).toBe('management')
    expect(model.entries.find((entry) => entry.campaignId === 'pulse-1')?.category).toBe('module')
    expect(model.entries.find((entry) => entry.campaignId === 'onboarding-1')?.category).toBe('cohort')
  })

  it('keeps culture assessment framed as a board-readable management report instead of a module layer', () => {
    const model = buildReportLibraryEntries(campaigns)
    const cultureEntry = model.entries.find((entry) => entry.campaignId === 'culture-1')

    expect(cultureEntry?.categoryLabel).toBe('Managementsamenvatting')
    expect(cultureEntry?.summary).toContain('Loep Culture Assessment')
    expect(cultureEntry?.summary.toLowerCase()).not.toContain('modulelaag')
    expect(model.featured?.description.toLowerCase()).not.toContain('ranking')
  })

  it('marks report-ready entries with shared bridge assessment truth', () => {
    const model = buildReportLibraryEntries(campaigns, {
      routeOpenableByCampaignId: {
        'exit-1': true,
      },
    })

    expect(model.entries.find((entry) => entry.campaignId === 'exit-1')?.bridgeState).toBe('candidate')
  })

  it('keeps report-ready entries on attention until canonical route-openable truth exists', () => {
    const model = buildReportLibraryEntries(campaigns)

    expect(model.entries.find((entry) => entry.campaignId === 'exit-1')?.bridgeState).toBe('attention')
  })

  it('allows report entries to become active when real route truth is available', () => {
    const model = buildReportLibraryEntries(campaigns, {
      routeEntryStageByCampaignId: {
        'exit-1': 'active',
      },
    })

    expect(model.entries.find((entry) => entry.campaignId === 'exit-1')?.bridgeState).toBe('active')
  })

  it('keeps the featured report on the same bridge policy as regular entries', () => {
    const model = buildReportLibraryEntries(campaigns, {
      routeEntryStageByCampaignId: {
        'culture-1': 'active',
      },
    })

    expect(model.featured?.bridgeState).toBe('active')
    expect(getReportEntryBridge(model.featured!)).toMatchObject({
      href: '/action-center',
      bridge: {
        ctaLabel: 'Open in Action Center',
      },
    })
  })

  it('keeps candidate and active report destinations aligned with reports bridge policy', () => {
    const candidateEntry = buildReportLibraryEntries(campaigns, {
      routeOpenableByCampaignId: {
        'exit-1': true,
      },
    }).entries.find((entry) => entry.campaignId === 'exit-1')
    const activeEntry = buildReportLibraryEntries(campaigns, {
      routeEntryStageByCampaignId: {
        'exit-1': 'active',
      },
    }).entries.find((entry) => entry.campaignId === 'exit-1')

    expect(candidateEntry).toBeDefined()
    expect(activeEntry).toBeDefined()
    expect(getReportEntryBridge(candidateEntry!)).toMatchObject({
      href: '/campaigns/exit-1',
      bridge: {
        ctaLabel: 'Ga naar campaign detail',
      },
    })
    expect(getReportEntryBridge(activeEntry!)).toMatchObject({
      href: '/action-center',
      bridge: {
        ctaLabel: 'Open in Action Center',
      },
    })
  })

  it('filters cards per category without inventing an all-in-one export layer', () => {
    const model = buildReportLibraryEntries(campaigns)

    expect(filterReportLibraryEntries(model.entries, 'all')).toHaveLength(4)
    expect(filterReportLibraryEntries(model.entries, 'management').map((entry) => entry.campaignId)).toEqual(['culture-1', 'exit-1'])
    expect(filterReportLibraryEntries(model.entries, 'module').map((entry) => entry.campaignId)).toEqual(['pulse-1'])
    expect(filterReportLibraryEntries(model.entries, 'cohort').map((entry) => entry.campaignId)).toEqual(['onboarding-1'])
  })

  it('prioritizes the seeded HR demo campaign in featured report selection when an artifact is present', () => {
    const model = buildReportLibraryEntries(campaigns, {
      hrDemoArtifact: {
        campaignId: 'pulse-1',
      },
    })

    expect(model.featured).toMatchObject({
      campaignId: 'pulse-1',
      scanType: 'pulse',
    })
    expect(model.entries.find((entry) => entry.campaignId === 'pulse-1')?.recommended).toBe(true)
    expect(model.entries.find((entry) => entry.campaignId === 'exit-1')?.recommended).toBe(false)
  })
})

